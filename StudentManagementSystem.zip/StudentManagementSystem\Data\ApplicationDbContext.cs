using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Student> Students => Set<Student>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.FullName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Email).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Course).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Grade).HasPrecision(5, 2);
            });

            // Initial seed data
            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    Id = 1,
                    FullName = "Aarav Sharma",
                    Email = "aarav.sharma@example.com",
                    Course = "Computer Science",
                    Semester = 3,
                    EnrollmentDate = new DateTime(2024, 7, 15),
                    Grade = 82.5m
                },
                new Student
                {
                    Id = 2,
                    FullName = "Priya Patel",
                    Email = "priya.patel@example.com",
                    Course = "Information Technology",
                    Semester = 5,
                    EnrollmentDate = new DateTime(2023, 7, 10),
                    Grade = 91.0m
                }
            );
        }
    }
}
