using StudentManagementSystem.Models;

namespace StudentManagementSystem.Repositories
{
    public interface IStudentRepository
    {
        IQueryable<Student> GetQueryable();
        Task<IEnumerable<Student>> GetAllAsync();
        Task<Student?> GetByIdAsync(int id, bool asNoTracking = false);
        Task<bool> ExistsAsync(int id);
        Task<bool> EmailExistsAsync(string email, int? excludeStudentId = null);
        Task AddAsync(Student student);
        void Update(Student student);
        void Delete(Student student);
        Task<int> SaveChangesAsync();
    }
}
