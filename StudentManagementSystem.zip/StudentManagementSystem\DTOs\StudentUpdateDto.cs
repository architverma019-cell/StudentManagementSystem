using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.DTOs
{
    public class StudentUpdateDto
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage = "Full name is required.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Full name must be between 2 and 100 characters.")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email address is required.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        [StringLength(100, ErrorMessage = "Email address cannot exceed 100 characters.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Course title is required.")]
        [StringLength(50, ErrorMessage = "Course title cannot exceed 50 characters.")]
        public string Course { get; set; } = string.Empty;

        [Range(1, 8, ErrorMessage = "Semester must be between 1 and 8.")]
        public int Semester { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Date of Enrollment")]
        public DateTime EnrollmentDate { get; set; }

        [Range(0.0, 100.0, ErrorMessage = "Grade must be between 0 and 100.")]
        [Display(Name = "Grade (%)")]
        public decimal Grade { get; set; }
    }
}
