# Student Management System

A simple CRUD web application built with **ASP.NET Core MVC** and **Entity Framework Core** (SQLite).

## Features
- Full CRUD (Create, Read, Update, Delete) for student records
- Search by name or course
- Server-side model validation (required fields, email format, grade range, etc.)
- SQLite database — no external database server needed
- Clean, responsive UI

## Tech Stack
- ASP.NET Core 8.0 (MVC)
- Entity Framework Core 8 with SQLite
- Razor Views
- Plain CSS (no framework dependency)

## Project Structure
```
StudentManagementSystem/
├── Controllers/
│   └── StudentsController.cs   # CRUD actions
├── Models/
│   └── Student.cs              # Student entity + validation
├── Data/
│   └── ApplicationDbContext.cs # EF Core DbContext + seed data
├── Views/
│   ├── Students/               # Index, Create, Edit, Details, Delete
│   └── Shared/_Layout.cshtml   # Shared layout
├── wwwroot/css/site.css        # Styling
├── Program.cs                  # App startup
└── appsettings.json            # Configuration (DB connection string)
```

## Getting Started

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download)

### Run locally
```bash
# 1. Clone the repo
git clone <your-repo-url>
cd StudentManagementSystem

# 2. Restore dependencies
dotnet restore

# 3. Run the app
dotnet run
```

The app will start (usually at `https://localhost:5001` or `http://localhost:5000` — check the console output for the exact URL). The SQLite database (`students.db`) is created automatically on first run, with two sample students already seeded.

## Notes
- The database file (`students.db`) is git-ignored since it's generated at runtime — don't worry if you don't see it in the repo.
- To reset the data, just delete `students.db` and restart the app.

## License
This project was created for academic/assignment purposes.
