using StudentManagementSystem.DTOs;

namespace StudentManagementSystem.Services
{
    public interface IStudentService
    {
        Task<PaginatedList<StudentDto>> GetStudentsAsync(string? searchString, string? courseFilter, string? sortOrder, int pageIndex = 1, int pageSize = 10);
        Task<IEnumerable<string>> GetUniqueCoursesAsync();
        Task<StudentDto?> GetStudentByIdAsync(int id);
        Task<StudentUpdateDto?> GetStudentForEditAsync(int id);
        Task<(bool Success, string? ErrorMessage, int StudentId)> CreateStudentAsync(StudentCreateDto dto);
        Task<(bool Success, string? ErrorMessage)> UpdateStudentAsync(StudentUpdateDto dto);
        Task<(bool Success, string? ErrorMessage)> DeleteStudentAsync(int id);
    }
}
