using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.DTOs;
using StudentManagementSystem.Mappings;
using StudentManagementSystem.Repositories;

namespace StudentManagementSystem.Services
{
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository _repository;
        private readonly ILogger<StudentService> _logger;

        public StudentService(IStudentRepository repository, ILogger<StudentService> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task<PaginatedList<StudentDto>> GetStudentsAsync(
            string? searchString,
            string? courseFilter,
            string? sortOrder,
            int pageIndex = 1,
            int pageSize = 10)
        {
            var query = _repository.GetQueryable().AsNoTracking();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                var search = searchString.Trim();
                query = query.Where(s => s.FullName.Contains(search) || s.Email.Contains(search) || s.Course.Contains(search));
            }

            if (!string.IsNullOrWhiteSpace(courseFilter))
            {
                query = query.Where(s => s.Course == courseFilter);
            }

            query = sortOrder switch
            {
                "name_desc" => query.OrderByDescending(s => s.FullName),
                "date" => query.OrderBy(s => s.EnrollmentDate),
                "date_desc" => query.OrderByDescending(s => s.EnrollmentDate),
                "grade" => query.OrderBy(s => s.Grade),
                "grade_desc" => query.OrderByDescending(s => s.Grade),
                "course" => query.OrderBy(s => s.Course),
                "course_desc" => query.OrderByDescending(s => s.Course),
                _ => query.OrderBy(s => s.FullName)
            };

            var totalCount = await query.CountAsync();
            var items = await query
                .Skip((pageIndex - 1) * pageSize)
                .Take(pageSize)
                .Select(s => s.ToDto())
                .ToListAsync();

            return new PaginatedList<StudentDto>(items, totalCount, pageIndex, pageSize);
        }

        public async Task<IEnumerable<string>> GetUniqueCoursesAsync()
        {
            return await _repository.GetQueryable()
                .AsNoTracking()
                .Select(s => s.Course)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();
        }

        public async Task<StudentDto?> GetStudentByIdAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id, asNoTracking: true);
            return student?.ToDto();
        }

        public async Task<StudentUpdateDto?> GetStudentForEditAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id, asNoTracking: true);
            return student?.ToUpdateDto();
        }

        public async Task<(bool Success, string? ErrorMessage, int StudentId)> CreateStudentAsync(StudentCreateDto dto)
        {
            if (await _repository.EmailExistsAsync(dto.Email))
            {
                return (false, "A student with this email address already exists.", 0);
            }

            try
            {
                var student = dto.ToEntity();
                await _repository.AddAsync(student);
                await _repository.SaveChangesAsync();

                _logger.LogInformation("Student {FullName} (ID: {Id}) created successfully.", student.FullName, student.Id);
                return (true, null, student.Id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating student {FullName}.", dto.FullName);
                return (false, "An error occurred while saving the student. Please try again.", 0);
            }
        }

        public async Task<(bool Success, string? ErrorMessage)> UpdateStudentAsync(StudentUpdateDto dto)
        {
            var student = await _repository.GetByIdAsync(dto.Id);
            if (student == null)
            {
                return (false, "Student record was not found.");
            }

            if (await _repository.EmailExistsAsync(dto.Email, excludeStudentId: dto.Id))
            {
                return (false, "Another student is already registered with this email address.");
            }

            try
            {
                dto.UpdateEntity(student);
                _repository.Update(student);
                await _repository.SaveChangesAsync();

                _logger.LogInformation("Student {FullName} (ID: {Id}) updated successfully.", student.FullName, student.Id);
                return (true, null);
            }
            catch (DbUpdateConcurrencyException ex)
            {
                _logger.LogError(ex, "Concurrency conflict while updating student ID: {Id}.", dto.Id);
                return (false, "The record was modified by another user. Please reload and try again.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error updating student ID: {Id}.", dto.Id);
                return (false, "An unexpected error occurred while updating the student.");
            }
        }

        public async Task<(bool Success, string? ErrorMessage)> DeleteStudentAsync(int id)
        {
            var student = await _repository.GetByIdAsync(id);
            if (student == null)
            {
                return (false, "Student record was not found.");
            }

            try
            {
                _repository.Delete(student);
                await _repository.SaveChangesAsync();

                _logger.LogInformation("Student ID: {Id} deleted successfully.", id);
                return (true, null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting student ID: {Id}.", id);
                return (false, "An error occurred while attempting to delete the student.");
            }
        }
    }
}
