using StudentManagementSystem.DTOs;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Mappings
{
    public static class StudentMappingExtensions
    {
        public static StudentDto ToDto(this Student student)
        {
            return new StudentDto
            {
                Id = student.Id,
                FullName = student.FullName,
                Email = student.Email,
                Course = student.Course,
                Semester = student.Semester,
                EnrollmentDate = student.EnrollmentDate,
                Grade = student.Grade
            };
        }

        public static StudentUpdateDto ToUpdateDto(this Student student)
        {
            return new StudentUpdateDto
            {
                Id = student.Id,
                FullName = student.FullName,
                Email = student.Email,
                Course = student.Course,
                Semester = student.Semester,
                EnrollmentDate = student.EnrollmentDate,
                Grade = student.Grade
            };
        }

        public static Student ToEntity(this StudentCreateDto dto)
        {
            return new Student
            {
                FullName = dto.FullName.Trim(),
                Email = dto.Email.Trim().ToLowerInvariant(),
                Course = dto.Course.Trim(),
                Semester = dto.Semester,
                EnrollmentDate = dto.EnrollmentDate,
                Grade = dto.Grade
            };
        }

        public static void UpdateEntity(this StudentUpdateDto dto, Student entity)
        {
            entity.FullName = dto.FullName.Trim();
            entity.Email = dto.Email.Trim().ToLowerInvariant();
            entity.Course = dto.Course.Trim();
            entity.Semester = dto.Semester;
            entity.EnrollmentDate = dto.EnrollmentDate;
            entity.Grade = dto.Grade;
        }
    }
}
