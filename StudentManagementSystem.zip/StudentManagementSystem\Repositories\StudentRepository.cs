using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Data;
using StudentManagementSystem.Models;

namespace StudentManagementSystem.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly ApplicationDbContext _context;

        public StudentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public IQueryable<Student> GetQueryable()
        {
            return _context.Students.AsQueryable();
        }

        public async Task<IEnumerable<Student>> GetAllAsync()
        {
            return await _context.Students
                .AsNoTracking()
                .OrderBy(s => s.FullName)
                .ToListAsync();
        }

        public async Task<Student?> GetByIdAsync(int id, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await _context.Students
                    .AsNoTracking()
                    .FirstOrDefaultAsync(s => s.Id == id);
            }

            return await _context.Students.FindAsync(id);
        }

        public async Task<bool> ExistsAsync(int id)
        {
            return await _context.Students.AnyAsync(e => e.Id == id);
        }

        public async Task<bool> EmailExistsAsync(string email, int? excludeStudentId = null)
        {
            var normalized = email.Trim().ToLower();
            var query = _context.Students.Where(s => s.Email.ToLower() == normalized);

            if (excludeStudentId.HasValue)
            {
                query = query.Where(s => s.Id != excludeStudentId.Value);
            }

            return await query.AnyAsync();
        }

        public async Task AddAsync(Student student)
        {
            await _context.Students.AddAsync(student);
        }

        public void Update(Student student)
        {
            _context.Students.Update(student);
        }

        public void Delete(Student student)
        {
            _context.Students.Remove(student);
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
