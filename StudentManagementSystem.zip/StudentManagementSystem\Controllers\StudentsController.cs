using Microsoft.AspNetCore.Mvc;
using StudentManagementSystem.DTOs;
using StudentManagementSystem.Services;

namespace StudentManagementSystem.Controllers
{
    public class StudentsController : Controller
    {
        private readonly IStudentService _studentService;
        private readonly ILogger<StudentsController> _logger;

        public StudentsController(IStudentService studentService, ILogger<StudentsController> logger)
        {
            _studentService = studentService;
            _logger = logger;
        }

        // GET: Students
        public async Task<IActionResult> Index(
            string? searchString,
            string? courseFilter,
            string? sortOrder,
            int pageNumber = 1)
        {
            ViewData["CurrentSort"] = sortOrder;
            ViewData["NameSortParm"] = string.IsNullOrEmpty(sortOrder) ? "name_desc" : "";
            ViewData["DateSortParm"] = sortOrder == "date" ? "date_desc" : "date";
            ViewData["GradeSortParm"] = sortOrder == "grade" ? "grade_desc" : "grade";
            ViewData["CourseSortParm"] = sortOrder == "course" ? "course_desc" : "course";
            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentCourse"] = courseFilter;

            ViewBag.Courses = await _studentService.GetUniqueCoursesAsync();

            var students = await _studentService.GetStudentsAsync(searchString, courseFilter, sortOrder, pageNumber, pageSize: 8);
            return View(students);
        }

        // GET: Students/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var student = await _studentService.GetStudentByIdAsync(id.Value);
            if (student == null) return NotFound();

            return View(student);
        }

        // GET: Students/Create
        public IActionResult Create()
        {
            return View(new StudentCreateDto());
        }

        // POST: Students/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(StudentCreateDto dto)
        {
            if (!ModelState.IsValid)
            {
                return View(dto);
            }

            var (success, errorMessage, studentId) = await _studentService.CreateStudentAsync(dto);
            if (!success)
            {
                ModelState.AddModelError(string.Empty, errorMessage ?? "Unable to create student.");
                return View(dto);
            }

            TempData["Success"] = $"Student '{dto.FullName}' was enrolled successfully.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Students/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var student = await _studentService.GetStudentForEditAsync(id.Value);
            if (student == null) return NotFound();

            return View(student);
        }

        // POST: Students/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, StudentUpdateDto dto)
        {
            if (id != dto.Id) return NotFound();

            if (!ModelState.IsValid)
            {
                return View(dto);
            }

            var (success, errorMessage) = await _studentService.UpdateStudentAsync(dto);
            if (!success)
            {
                ModelState.AddModelError(string.Empty, errorMessage ?? "Unable to update student.");
                return View(dto);
            }

            TempData["Success"] = $"Student '{dto.FullName}' was updated successfully.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Students/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var student = await _studentService.GetStudentByIdAsync(id.Value);
            if (student == null) return NotFound();

            return View(student);
        }

        // POST: Students/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var (success, errorMessage) = await _studentService.DeleteStudentAsync(id);
            if (success)
            {
                TempData["Success"] = "Student record was successfully deleted.";
            }
            else
            {
                TempData["Error"] = errorMessage ?? "Unable to delete student.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
