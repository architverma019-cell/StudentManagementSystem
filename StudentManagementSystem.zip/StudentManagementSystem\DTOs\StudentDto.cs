using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.DTOs
{
    public class StudentDto
    {
        public int Id { get; set; }

        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Course { get; set; } = string.Empty;

        public int Semester { get; set; }

        [Display(Name = "Date of Enrollment")]
        [DataType(DataType.Date)]
        public DateTime EnrollmentDate { get; set; }

        [Display(Name = "Grade (%)")]
        public decimal Grade { get; set; }

        public string GradeClassification => Grade switch
        {
            >= 90 => "A+ (Outstanding)",
            >= 80 => "A (Excellent)",
            >= 70 => "B (Very Good)",
            >= 60 => "C (Good)",
            >= 50 => "D (Pass)",
            _ => "F (Fail)"
        };

        public string StatusBadgeClass => Grade switch
        {
            >= 80 => "badge-success",
            >= 60 => "badge-info",
            >= 50 => "badge-warning",
            _ => "badge-danger"
        };
    }
}
